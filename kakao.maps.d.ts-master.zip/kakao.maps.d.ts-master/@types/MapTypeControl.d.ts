/// <reference path="index.d.ts" />

declare namespace kakao.maps {
  /**
   * @see [MapTypeControl](https://apis.map.kakao.com/web/documentation/#MapTypeControl)
   */
  export class MapTypeControl {
    constructor();
  }
}
