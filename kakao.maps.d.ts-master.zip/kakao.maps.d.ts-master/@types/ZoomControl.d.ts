/// <reference path="index.d.ts" />

declare namespace kakao.maps {
  /**
   * @see [ZoomControl](https://apis.map.kakao.com/web/documentation/#ZoomControl)
   */
  export class ZoomControl {
    constructor();
  }
}
